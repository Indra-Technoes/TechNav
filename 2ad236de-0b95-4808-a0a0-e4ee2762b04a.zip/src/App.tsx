import React, { useState } from 'react';
import { Header } from './components/Header';
import { TabNavigation } from './components/TabNavigation';
import { KedatanganKeberangkatan } from './pages/KedatanganKeberangkatan';
import { LaluLintas } from './pages/LaluLintas';
import { BongkarMuat } from './pages/BongkarMuat';
import { PemantauanDermaga } from './pages/PemantauanDermaga';
type TabId = 'kedatangan' | 'lalulintas' | 'bongkarmuat' | 'dermaga';
export function App() {
  const [activeTab, setActiveTab] = useState<TabId>('kedatangan');
  const renderContent = () => {
    switch (activeTab) {
      case 'kedatangan':
        return <KedatanganKeberangkatan />;
      case 'lalulintas':
        return <LaluLintas />;
      case 'bongkarmuat':
        return <BongkarMuat />;
      case 'dermaga':
        return <PemantauanDermaga />;
      default:
        return <KedatanganKeberangkatan />;
    }
  };
  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      <Header />
      <TabNavigation activeTab={activeTab} onTabChange={setActiveTab} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>

      <footer className="bg-white border-t border-slate-200 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <p className="text-center text-sm text-slate-500">
            &copy; 2024 TechNAV - Technoes Navigator System - Direktorat
            Jenderal Perhubungan Laut. Hak Cipta Dilindungi.
          </p>
        </div>
      </footer>
    </div>);

}