import React from 'react';
import { Search, Filter } from 'lucide-react';
interface SearchFilterProps {
  placeholder?: string;
  onSearch?: (query: string) => void;
  filterOptions?: string[];
}
export function SearchFilter({
  placeholder = 'Cari data...',
  onSearch,
  filterOptions = ['Semua Status', 'Aktif', 'Selesai']
}: SearchFilterProps) {
  return (
    <div className="flex flex-col sm:flex-row gap-4 mb-6">
      <div className="relative flex-1">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-slate-400" />
        </div>
        <input
          type="text"
          className="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg leading-5 bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition-shadow"
          placeholder={placeholder}
          onChange={(e) => onSearch && onSearch(e.target.value)} />

      </div>
      <div className="sm:w-48 relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Filter className="h-4 w-4 text-slate-400" />
        </div>
        <select className="block w-full pl-10 pr-10 py-2.5 border border-slate-300 rounded-lg leading-5 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm appearance-none cursor-pointer">
          {filterOptions.map((opt) =>
          <option key={opt}>{opt}</option>
          )}
        </select>
        <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
          <svg
            className="h-4 w-4 text-slate-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24">

            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M19 9l-7 7-7-7" />

          </svg>
        </div>
      </div>
    </div>);

}