import React from 'react';
import { Ship, Navigation, Package, Anchor } from 'lucide-react';
type TabId = 'kedatangan' | 'lalulintas' | 'bongkarmuat' | 'dermaga';
interface TabNavigationProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
}
export function TabNavigation({ activeTab, onTabChange }: TabNavigationProps) {
  const tabs = [
  {
    id: 'kedatangan',
    label: 'Kedatangan & Keberangkatan',
    icon: Ship
  },
  {
    id: 'lalulintas',
    label: 'Lalu Lintas',
    icon: Navigation
  },
  {
    id: 'bongkarmuat',
    label: 'Bongkar Muat',
    icon: Package
  },
  {
    id: 'dermaga',
    label: 'Pemantauan Dermaga',
    icon: Anchor
  }] as
  const;
  return (
    <div className="bg-white border-b border-slate-200 sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex space-x-8 overflow-x-auto" aria-label="Tabs">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`
                  group inline-flex items-center py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-all duration-200
                  ${isActive ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'}
                `}>

                <Icon
                  className={`
                    -ml-0.5 mr-2 h-5 w-5
                    ${isActive ? 'text-blue-600' : 'text-slate-400 group-hover:text-slate-500'}
                  `} />

                {tab.label}
              </button>);

          })}
        </nav>
      </div>
    </div>);

}