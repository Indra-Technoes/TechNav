import React from 'react';
import { ChevronRight, Home } from 'lucide-react';
interface BreadcrumbsProps {
  items: string[];
}
export function Breadcrumbs({ items }: BreadcrumbsProps) {
  return (
    <nav className="flex" aria-label="Breadcrumb">
      <ol className="flex items-center space-x-2">
        <li>
          <div>
            <a href="#" className="text-slate-400 hover:text-slate-500">
              <Home className="h-4 w-4" />
              <span className="sr-only">Beranda</span>
            </a>
          </div>
        </li>
        {items.map((item, index) =>
        <li key={item}>
            <div className="flex items-center">
              <ChevronRight className="h-4 w-4 text-slate-300 flex-shrink-0" />
              <span
              className={`ml-2 text-sm font-medium ${index === items.length - 1 ? 'text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}>

                {item}
              </span>
            </div>
          </li>
        )}
      </ol>
    </nav>);

}