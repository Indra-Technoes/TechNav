import React from 'react';
import { Bell, User } from 'lucide-react';
export function Header() {
  return (
    <header className="bg-gray-100 text-slate-800 shadow-md border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          {/* Logo & Title */}
          <div className="flex items-center gap-4">
            <img
              src="/image.png"
              alt="TechNAV Logo"
              className="h-10 w-auto" />

            <div>
              <h1 className="text-lg font-bold leading-tight text-slate-800">
                Technoes Navigator System
              </h1>
              <p className="text-xs text-blue-600 tracking-wider">
                DJPL No. 48 - OTORITAS PELABUHAN
              </p>
            </div>
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-4">
            <button className="p-2 text-slate-500 hover:text-slate-700 transition-colors relative">
              <Bell className="h-5 w-5" />
              <span className="absolute top-1.5 right-1.5 h-2 w-2 bg-orange-500 rounded-full border border-gray-100"></span>
            </button>
            <div className="h-8 w-px bg-gray-300 mx-2"></div>
            <div className="flex items-center gap-3">
              <div className="text-right hidden md:block">
                <p className="text-sm font-medium text-slate-700">
                  Kapten Budi Santoso
                </p>
                <p className="text-xs text-slate-500">
                  Administrator Pelabuhan
                </p>
              </div>
              <div className="h-10 w-10 bg-gray-200 rounded-full flex items-center justify-center border border-gray-300">
                <User className="h-5 w-5 text-slate-600" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>);

}