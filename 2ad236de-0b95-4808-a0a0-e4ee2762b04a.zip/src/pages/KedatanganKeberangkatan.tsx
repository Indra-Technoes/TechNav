import React, { useState } from 'react';
import { Plus, Edit2, Trash2, Calendar, Anchor } from 'lucide-react';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { SearchFilter } from '../components/SearchFilter';
export function KedatanganKeberangkatan() {
  const [showForm, setShowForm] = useState(false);
  const ships = [
  {
    id: 1,
    name: 'KM. Nusantara 45',
    imo: '9823451',
    flag: 'Indonesia',
    captain: 'Budi Raharjo',
    eta: '2023-10-24 14:00',
    etd: '2023-10-26 08:00',
    status: 'Berlabuh'
  },
  {
    id: 2,
    name: 'MV. Ocean Star',
    imo: '8765432',
    flag: 'Panama',
    captain: 'John Smith',
    eta: '2023-10-25 09:30',
    etd: '2023-10-27 16:00',
    status: 'Dijadwalkan'
  },
  {
    id: 3,
    name: 'TB. Perkasa 01',
    imo: '9123789',
    flag: 'Indonesia',
    captain: 'Slamet Riyadi',
    eta: '2023-10-23 10:00',
    etd: '2023-10-24 13:00',
    status: 'Berangkat'
  },
  {
    id: 4,
    name: 'KM. Logistik Raya',
    imo: '9988776',
    flag: 'Singapore',
    captain: 'Tan Wei Ming',
    eta: '2023-10-26 06:00',
    etd: '2023-10-28 18:00',
    status: 'Dijadwalkan'
  },
  {
    id: 5,
    name: 'MT. Energi Bangsa',
    imo: '9554433',
    flag: 'Indonesia',
    captain: 'Hendra Gunawan',
    eta: '2023-10-24 16:45',
    etd: '2023-10-25 20:00',
    status: 'Berlabuh'
  }];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Berlabuh':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Dijadwalkan':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Berangkat':
        return 'bg-slate-100 text-slate-800 border-slate-200';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <Breadcrumbs items={['Beranda', 'Kedatangan & Keberangkatan']} />
        <button
          onClick={() => setShowForm(!showForm)}
          className="inline-flex items-center px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white text-sm font-medium rounded-lg transition-colors shadow-sm">

          <Plus className="h-4 w-4 mr-2" />
          Registrasi Kapal
        </button>
      </div>

      {showForm &&
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 mb-6 animate-in slide-in-from-top-4 duration-300">
          <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center">
            <Anchor className="h-5 w-5 mr-2 text-blue-600" />
            Formulir Registrasi Kapal Baru
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Nama Kapal
              </label>
              <input
              type="text"
              className="w-full rounded-lg border-slate-300 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Contoh: KM. Nusantara" />

            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Nomor IMO
              </label>
              <input
              type="text"
              className="w-full rounded-lg border-slate-300 focus:ring-blue-500 focus:border-blue-500"
              placeholder="7 digit angka" />

            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Bendera
              </label>
              <input
              type="text"
              className="w-full rounded-lg border-slate-300 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Negara Asal" />

            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Nama Kapten
              </label>
              <input
              type="text"
              className="w-full rounded-lg border-slate-300 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Nama Lengkap" />

            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                ETA (Estimasi Tiba)
              </label>
              <input
              type="datetime-local"
              className="w-full rounded-lg border-slate-300 focus:ring-blue-500 focus:border-blue-500" />

            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                ETD (Estimasi Berangkat)
              </label>
              <input
              type="datetime-local"
              className="w-full rounded-lg border-slate-300 focus:ring-blue-500 focus:border-blue-500" />

            </div>
          </div>
          <div className="mt-6 flex justify-end gap-3">
            <button
            onClick={() => setShowForm(false)}
            className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50">

              Batal
            </button>
            <button className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 shadow-sm">
              Simpan Data
            </button>
          </div>
        </div>
      }

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-6 border-b border-slate-200">
          <h2 className="text-xl font-bold text-slate-900">Jadwal Kapal</h2>
          <p className="text-slate-500 text-sm mt-1">
            Daftar semua kapal yang dijadwalkan, sedang berlabuh, atau telah
            berangkat.
          </p>
        </div>

        <div className="p-6">
          <SearchFilter
            filterOptions={[
            'Semua Status',
            'Dijadwalkan',
            'Berlabuh',
            'Berangkat']
            } />


          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">

                    Nama Kapal / IMO
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">

                    Bendera / Kapten
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">

                    Jadwal (ETA / ETD)
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">

                    Status
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">

                    Aksi
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {ships.map((ship) =>
                <tr
                  key={ship.id}
                  className="hover:bg-slate-50 transition-colors">

                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
                          <ShipIcon className="h-5 w-5" />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-slate-900">
                            {ship.name}
                          </div>
                          <div className="text-sm text-slate-500">
                            IMO: {ship.imo}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-slate-900">{ship.flag}</div>
                      <div className="text-sm text-slate-500">
                        {ship.captain}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-slate-900 flex items-center">
                        <span className="w-8 text-xs text-slate-400">ETA:</span>{' '}
                        {ship.eta}
                      </div>
                      <div className="text-sm text-slate-500 flex items-center">
                        <span className="w-8 text-xs text-slate-400">ETD:</span>{' '}
                        {ship.etd}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                      className={`px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full border ${getStatusColor(ship.status)}`}>

                        {ship.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex justify-end gap-2">
                        <button className="text-blue-600 hover:text-blue-900 p-1 rounded hover:bg-blue-50">
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button className="text-red-600 hover:text-red-900 p-1 rounded hover:bg-red-50">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>);

}
function ShipIcon({ className }: {className?: string;}) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round">

      <path d="M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.3 0 1.9 1 2.5 1 .6 0 1.2-1 2.5-1 2.5 0 2.5 2 5 2 1.3 0 1.9-1 2.5-1" />
      <path d="M19.38 20A11.6 11.6 0 0 0 21 14l-9-4-9 4c0 2.9.9 5.8 2.8 8" />
      <path d="M5 10l7-4 7 4" />
      <path d="M12 2v4" />
    </svg>);

}