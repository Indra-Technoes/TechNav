import React from 'react';
import { Navigation, Wind, Compass, MapPin, Activity } from 'lucide-react';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { SearchFilter } from '../components/SearchFilter';
export function LaluLintas() {
  const trafficData = [
  {
    id: 1,
    name: 'KM. Nusantara 45',
    type: 'Cargo',
    lat: '-6.1234',
    long: '106.8765',
    speed: '12.5 kn',
    heading: '270°',
    status: 'Moving'
  },
  {
    id: 2,
    name: 'MT. Energi Bangsa',
    type: 'Tanker',
    lat: '-6.1245',
    long: '106.8801',
    speed: '0.0 kn',
    heading: '180°',
    status: 'Anchored'
  },
  {
    id: 3,
    name: 'MV. Ocean Star',
    type: 'Container',
    lat: '-6.1300',
    long: '106.8900',
    speed: '8.2 kn',
    heading: '045°',
    status: 'Moving'
  },
  {
    id: 4,
    name: 'KMP. Ferry Jaya',
    type: 'Passenger',
    lat: '-6.1280',
    long: '106.8650',
    speed: '15.0 kn',
    heading: '090°',
    status: 'Moving'
  },
  {
    id: 5,
    name: 'TB. Perkasa 01',
    type: 'Tug',
    lat: '-6.1260',
    long: '106.8720',
    speed: '4.5 kn',
    heading: '315°',
    status: 'Towing'
  },
  {
    id: 6,
    name: 'KM. Nelayan 08',
    type: 'Fishing',
    lat: '-6.1350',
    long: '106.8550',
    speed: '2.1 kn',
    heading: '120°',
    status: 'Fishing'
  }];

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Cargo':
        return 'bg-blue-100 text-blue-800';
      case 'Tanker':
        return 'bg-red-100 text-red-800';
      case 'Passenger':
        return 'bg-purple-100 text-purple-800';
      case 'Tug':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <Breadcrumbs items={['Beranda', 'Lalu Lintas Kapal']} />

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex items-center">
          <div className="p-3 rounded-full bg-blue-100 text-blue-600 mr-4">
            <Navigation className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">
              Total Kapal Aktif
            </p>
            <p className="text-2xl font-bold text-slate-900">42</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex items-center">
          <div className="p-3 rounded-full bg-green-100 text-green-600 mr-4">
            <Activity className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Masuk Hari Ini</p>
            <p className="text-2xl font-bold text-slate-900">18</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex items-center">
          <div className="p-3 rounded-full bg-orange-100 text-orange-600 mr-4">
            <Wind className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">
              Keluar Hari Ini
            </p>
            <p className="text-2xl font-bold text-slate-900">12</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-slate-900">
            Pemantauan Real-time
          </h2>
          <div className="flex gap-2">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
              <span className="w-2 h-2 bg-green-500 rounded-full mr-1.5 animate-pulse"></span>
              Live Update
            </span>
          </div>
        </div>

        <SearchFilter
          filterOptions={['Semua Tipe', 'Cargo', 'Tanker', 'Passenger', 'Tug']} />


        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trafficData.map((ship) =>
          <div
            key={ship.id}
            className="group bg-white border border-slate-200 rounded-xl p-5 hover:shadow-md hover:border-blue-300 transition-all duration-200">

              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-bold text-slate-900 text-lg group-hover:text-blue-600 transition-colors">
                    {ship.name}
                  </h3>
                  <span
                  className={`inline-block mt-1 px-2 py-0.5 text-xs font-medium rounded ${getTypeColor(ship.type)}`}>

                    {ship.type}
                  </span>
                </div>
                <div
                className={`h-2 w-2 rounded-full ${ship.status === 'Moving' ? 'bg-green-500' : 'bg-orange-500'}`}
                title={ship.status}>
              </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center text-slate-600">
                  <MapPin className="h-4 w-4 mr-2 text-slate-400" />
                  <span>
                    {ship.lat}, {ship.long}
                  </span>
                </div>
                <div className="flex items-center text-slate-600">
                  <Activity className="h-4 w-4 mr-2 text-slate-400" />
                  <span>{ship.speed}</span>
                </div>
                <div className="flex items-center text-slate-600">
                  <Compass className="h-4 w-4 mr-2 text-slate-400" />
                  <span>{ship.heading}</span>
                </div>
                <div className="flex items-center text-slate-600">
                  <span className="w-4 h-4 mr-2 flex items-center justify-center text-xs font-bold text-slate-400">
                    ST
                  </span>
                  <span>{ship.status}</span>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-slate-100 flex justify-between items-center">
                <span className="text-xs text-slate-400">
                  Last update: 2 mins ago
                </span>
                <button className="text-sm font-medium text-blue-600 hover:text-blue-800">
                  Detail &rarr;
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>);

}