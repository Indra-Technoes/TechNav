import React from 'react';
import { Package, Truck, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { SearchFilter } from '../components/SearchFilter';
export function BongkarMuat() {
  const operations = [
  {
    id: 1,
    vessel: 'KM. Nusantara 45',
    cargo: 'Beras',
    tonnage: '5,000 Ton',
    progress: 75,
    status: 'Berlangsung',
    start: '08:00 WIB',
    type: 'Bongkar'
  },
  {
    id: 2,
    vessel: 'MV. Ocean Star',
    cargo: 'Elektronik',
    tonnage: '250 TEUs',
    progress: 30,
    status: 'Berlangsung',
    start: '10:30 WIB',
    type: 'Muat'
  },
  {
    id: 3,
    vessel: 'MT. Energi Bangsa',
    cargo: 'CPO',
    tonnage: '3,500 Ton',
    progress: 100,
    status: 'Selesai',
    start: 'Kemarin',
    type: 'Bongkar'
  },
  {
    id: 4,
    vessel: 'TB. Perkasa 01',
    cargo: 'Batubara',
    tonnage: '7,000 Ton',
    progress: 0,
    status: 'Menunggu',
    start: '14:00 WIB',
    type: 'Muat'
  }];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Berlangsung':
        return 'text-blue-600 bg-blue-50';
      case 'Selesai':
        return 'text-green-600 bg-green-50';
      case 'Menunggu':
        return 'text-orange-600 bg-orange-50';
      default:
        return 'text-slate-600 bg-slate-50';
    }
  };
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <Breadcrumbs items={['Beranda', 'Operasi Bongkar Muat']} />

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white shadow-lg">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-blue-100 font-medium text-sm">Total Operasi</p>
              <h3 className="text-3xl font-bold mt-1">12</h3>
            </div>
            <Package className="h-8 w-8 text-blue-200 opacity-50" />
          </div>
          <div className="mt-4 text-sm text-blue-100">
            Target harian: 15 operasi
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-slate-500 font-medium text-sm">
                Bongkar Aktif
              </p>
              <h3 className="text-3xl font-bold text-slate-900 mt-1">5</h3>
            </div>
            <div className="p-2 bg-orange-100 rounded-lg">
              <Truck className="h-6 w-6 text-orange-600" />
            </div>
          </div>
          <div className="mt-4 w-full bg-slate-100 rounded-full h-1.5">
            <div
              className="bg-orange-500 h-1.5 rounded-full"
              style={{
                width: '60%'
              }}>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-slate-500 font-medium text-sm">Muat Aktif</p>
              <h3 className="text-3xl font-bold text-slate-900 mt-1">3</h3>
            </div>
            <div className="p-2 bg-green-100 rounded-lg">
              <Package className="h-6 w-6 text-green-600" />
            </div>
          </div>
          <div className="mt-4 w-full bg-slate-100 rounded-full h-1.5">
            <div
              className="bg-green-500 h-1.5 rounded-full"
              style={{
                width: '40%'
              }}>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h2 className="text-xl font-bold text-slate-900 mb-6">
          Daftar Operasi
        </h2>
        <SearchFilter
          filterOptions={['Semua Status', 'Berlangsung', 'Menunggu', 'Selesai']} />


        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {operations.map((op) =>
          <div
            key={op.id}
            className="border border-slate-200 rounded-xl p-5 hover:shadow-md transition-shadow bg-white">

              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                  <div
                  className={`p-2 rounded-lg ${op.type === 'Bongkar' ? 'bg-orange-100 text-orange-600' : 'bg-blue-100 text-blue-600'}`}>

                    {op.type === 'Bongkar' ?
                  <Truck className="h-5 w-5" /> :

                  <Package className="h-5 w-5" />
                  }
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900">{op.vessel}</h3>
                    <p className="text-sm text-slate-500">
                      {op.cargo} • {op.tonnage}
                    </p>
                  </div>
                </div>
                <span
                className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(op.status)}`}>

                  {op.status}
                </span>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-600">Progress</span>
                  <span className="font-medium text-slate-900">
                    {op.progress}%
                  </span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                  <div
                  className={`h-2.5 rounded-full transition-all duration-1000 ${op.progress === 100 ? 'bg-green-500' : 'bg-blue-600'}`}
                  style={{
                    width: `${op.progress}%`
                  }}>
                </div>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-slate-100 flex justify-between items-center text-sm">
                <div className="flex items-center text-slate-500">
                  <Clock className="h-4 w-4 mr-1.5" />
                  Mulai: {op.start}
                </div>
                {op.status === 'Selesai' ?
              <button className="text-green-600 font-medium flex items-center hover:underline">
                    <CheckCircle className="h-4 w-4 mr-1" /> Laporan
                  </button> :

              <button className="text-blue-600 font-medium flex items-center hover:underline">
                    <AlertCircle className="h-4 w-4 mr-1" /> Detail
                  </button>
              }
              </div>
            </div>
          )}
        </div>
      </div>
    </div>);

}