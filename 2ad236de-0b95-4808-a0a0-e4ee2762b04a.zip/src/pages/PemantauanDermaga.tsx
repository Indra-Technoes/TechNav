import React from 'react';
import { Anchor, Clock, AlertTriangle } from 'lucide-react';
import { Breadcrumbs } from '../components/Breadcrumbs';
export function PemantauanDermaga() {
  const berths = [
  {
    id: 'D1',
    name: 'Dermaga 1',
    status: 'Terisi',
    vessel: 'KM. Nusantara 45',
    duration: '4h 30m',
    type: 'General Cargo'
  },
  {
    id: 'D2',
    name: 'Dermaga 2',
    status: 'Kosong',
    vessel: '-',
    duration: '-',
    type: 'General Cargo'
  },
  {
    id: 'D3',
    name: 'Dermaga 3',
    status: 'Terisi',
    vessel: 'MV. Ocean Star',
    duration: '12h 15m',
    type: 'Container'
  },
  {
    id: 'D4',
    name: 'Dermaga 4',
    status: 'Maintenance',
    vessel: '-',
    duration: 'Est. 2 days',
    type: 'Liquid Bulk'
  },
  {
    id: 'D5',
    name: 'Dermaga 5',
    status: 'Terisi',
    vessel: 'MT. Energi Bangsa',
    duration: '1h 45m',
    type: 'Liquid Bulk'
  },
  {
    id: 'D6',
    name: 'Dermaga 6',
    status: 'Kosong',
    vessel: '-',
    duration: '-',
    type: 'Passenger'
  }];

  return (
    <div className="h-[calc(100vh-12rem)] flex flex-col animate-in fade-in duration-500">
      <div className="mb-4">
        <Breadcrumbs items={['Beranda', 'Pemantauan Dermaga']} />
      </div>

      <div className="flex-1 flex flex-col lg:flex-row gap-6 min-h-0">
        {/* Map Visualization Area */}
        <div className="lg:w-3/5 bg-slate-900 rounded-xl overflow-hidden shadow-lg border border-slate-700 relative flex flex-col">
          <div className="absolute top-4 left-4 z-10 bg-slate-800/90 backdrop-blur px-3 py-1.5 rounded-lg border border-slate-600 text-white text-sm font-medium">
            Live Port Map View
          </div>

          {/* Abstract Port Map Representation */}
          <div className="flex-1 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] bg-slate-800 relative p-8 flex items-center justify-center">
            {/* Water Area */}
            <div className="absolute inset-0 bg-blue-900/20 pointer-events-none"></div>

            {/* Dock Structure Visualization */}
            <div className="relative w-full h-full max-w-2xl grid grid-cols-2 gap-8 p-8 border-4 border-slate-600/50 rounded-3xl bg-slate-800/50">
              {/* Left Docks */}
              <div className="space-y-8 flex flex-col justify-center border-r-4 border-dashed border-slate-600/30 pr-8">
                {berths.slice(0, 3).map((berth) =>
                <div
                  key={berth.id}
                  className={`
                    relative h-24 rounded-l-xl border-2 flex items-center justify-center transition-all
                    ${berth.status === 'Terisi' ? 'bg-blue-500/20 border-blue-500' : berth.status === 'Maintenance' ? 'bg-orange-500/20 border-orange-500' : 'bg-slate-700/30 border-slate-600'}
                  `}>

                    <span className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-slate-900 border border-slate-600 rounded-full flex items-center justify-center text-xs font-bold text-slate-400">
                      {berth.id}
                    </span>
                    {berth.status === 'Terisi' &&
                  <div className="w-3/4 h-12 bg-blue-600 rounded shadow-lg flex items-center justify-center text-white text-xs font-bold">
                        {berth.vessel}
                      </div>
                  }
                  </div>
                )}
              </div>

              {/* Right Docks */}
              <div className="space-y-8 flex flex-col justify-center pl-8">
                {berths.slice(3, 6).map((berth) =>
                <div
                  key={berth.id}
                  className={`
                    relative h-24 rounded-r-xl border-2 flex items-center justify-center transition-all
                    ${berth.status === 'Terisi' ? 'bg-blue-500/20 border-blue-500' : berth.status === 'Maintenance' ? 'bg-orange-500/20 border-orange-500' : 'bg-slate-700/30 border-slate-600'}
                  `}>

                    <span className="absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-slate-900 border border-slate-600 rounded-full flex items-center justify-center text-xs font-bold text-slate-400">
                      {berth.id}
                    </span>
                    {berth.status === 'Terisi' &&
                  <div className="w-3/4 h-12 bg-blue-600 rounded shadow-lg flex items-center justify-center text-white text-xs font-bold">
                        {berth.vessel}
                      </div>
                  }
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Dashboard Side Panel */}
        <div className="lg:w-2/5 flex flex-col gap-4 overflow-y-auto pr-1">
          <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200">
            <h3 className="font-bold text-slate-900 mb-4">Statistik Dermaga</h3>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-2xl font-bold text-slate-900">6</div>
                <div className="text-xs text-slate-500">Total Slot</div>
              </div>
              <div className="p-3 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">3</div>
                <div className="text-xs text-blue-600">Terisi</div>
              </div>
              <div className="p-3 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">2</div>
                <div className="text-xs text-green-600">Kosong</div>
              </div>
            </div>
          </div>

          <div className="flex-1 bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
            <div className="p-4 border-b border-slate-200 bg-slate-50">
              <h3 className="font-bold text-slate-900">Status Detail</h3>
            </div>
            <div className="overflow-y-auto p-4 space-y-3 flex-1">
              {berths.map((berth) =>
              <div
                key={berth.id}
                className="flex items-center justify-between p-3 border border-slate-100 rounded-lg hover:bg-slate-50 transition-colors">

                  <div className="flex items-center gap-3">
                    <div
                    className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold ${berth.status === 'Terisi' ? 'bg-blue-100 text-blue-600' : berth.status === 'Maintenance' ? 'bg-orange-100 text-orange-600' : 'bg-slate-100 text-slate-400'}`}>

                      {berth.id}
                    </div>
                    <div>
                      <div className="font-medium text-slate-900">
                        {berth.name}
                      </div>
                      <div className="text-xs text-slate-500">{berth.type}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div
                    className={`text-sm font-medium ${berth.status === 'Terisi' ? 'text-blue-600' : berth.status === 'Maintenance' ? 'text-orange-600' : 'text-slate-500'}`}>

                      {berth.status}
                    </div>
                    {berth.status === 'Terisi' &&
                  <div className="text-xs text-slate-400 flex items-center justify-end mt-0.5">
                        <Clock className="h-3 w-3 mr-1" /> {berth.duration}
                      </div>
                  }
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>);

}